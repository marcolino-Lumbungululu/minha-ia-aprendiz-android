import re


RUIDO = [
    "página inicial", "remover anúncios", "leia também",
    "todos os exercícios", "continuar no", "assinar",
    "copyright", "iniciar sessão", "criar conta",
    "home química", "ciências e descobertas",
    "pontos de chave", "busque assinar", "cronograma",
    "assistente de tarefa de casa", "menu"
]


def limpar_texto(texto):
    """Limpa o texto preservando a estrutura dos parágrafos."""
    texto = str(texto or "")
    texto = re.sub(
        r"Texto recolhido da página:\s*",
        "",
        texto,
        flags=re.I,
    )
    texto = re.sub(
        r"Resumo da pesquisa:\s*",
        "",
        texto,
        flags=re.I,
    )
    texto = re.sub(r"https?://\S+", "", texto)
    texto = texto.replace("\ufeff", "")

    linhas = []
    for linha in texto.splitlines():
        linha = re.sub(r"[ \t]+", " ", linha).strip()
        linhas.append(linha)

    texto = "\n".join(linhas)
    texto = re.sub(r"\n{3,}", "\n\n", texto)

    return texto.strip()


def dividir_frases(texto):
    """Separa frases e cabeçalhos comuns colados ao texto extraído."""
    texto = str(texto or "")
    texto = re.sub(r"\s+\*\s+", ". ", texto)
    texto = re.sub(r"\s+[•▪]\s*", ". ", texto)

    # Separar cabeçalhos comuns quando aparecem colados à frase seguinte.
    # A informação depois do cabeçalho é preservada.
    cabecalhos = (
        "Organismos fotossintéticos anoxigênicos",
        "Organismos fotossintéticos anoxigénicos",
        "Mecanismo",
        "Introdução",
        "Conclusão",
        "Referências",
        "Bibliografia",
        "Características",
        "Vantagens",
        "Desvantagens",
        "Etapas",
        "Exemplos",
        "Resumo",
    )

    for cabecalho in cabecalhos:
        texto = re.sub(
            r"(?i)(?<!^)(?<![.!?])\s+"
            + re.escape(cabecalho)
            + r"\s+(?=[A-ZÁÀÂÃÉÊÍÓÔÕÚÇ])",
            ". ",
            texto,
        )

    # Separar o título repetido da definição quando estão colados.
    texto = re.sub(
        r"(?i)\b(Fotossíntese anoxigênica)\s+"
        r"(?=A fotossíntese anoxigênica\b)",
        r"\1. ",
        texto,
    )

    # Separar cabeçalhos científicos colados à explicação.
    texto = re.sub(
        r"(?i)(Fórmula da Velocidade Média)\s+"
        r"(?=[A-ZÁÀÂÃÉÊÍÓÔÕÚÇ])",
        r"\1. ",
        texto,
    )

    return re.split(r"(?<=[.!?])\s+", texto)

def normalizar(texto):
    import unicodedata
    texto = str(texto).casefold()
    texto = unicodedata.normalize("NFD", texto)
    texto = "".join(
        c for c in texto
        if unicodedata.category(c) != "Mn"
    )
    return texto


PALAVRAS_PERGUNTA = {
    "como", "funciona", "funcionar", "qual", "quais",
    "que", "quem", "quando", "onde", "porque", "porquê",
    "explica", "explicar", "explique", "define", "definir",
    "definicao", "significa", "significado", "sobre",
    "para", "uma", "umas", "um", "uns", "dos", "das",
    "do", "da", "de", "e", "ou", "a", "o", "as", "os",
    "se", "calcula", "calcular", "calculo", "formula",
    "mostra", "diz", "indica", "quero", "saber", "me",
    "podes", "pode", "ser", "isso", "esta", "este",
    "na", "no", "nas", "nos", "pela", "pelo"
}


def termos_chave(texto):
    palavras = re.findall(
        r"[a-záéíóúâêôãõç]+",
        str(texto).casefold()
    )
    resultado = []

    for palavra in palavras:
        palavra_normalizada = normalizar(palavra)

        if (
            len(palavra_normalizada) >= 3
            and palavra_normalizada not in PALAVRAS_PERGUNTA
            and palavra_normalizada not in resultado
        ):
            resultado.append(palavra_normalizada)

    return resultado


def pontuar_frase(frase, pergunta):
    frase_normalizada = normalizar(frase)
    pergunta_normalizada = normalizar(pergunta)
    intencao = identificar_intencao(pergunta)
    pontos = 0

    # Adequar a pontuação ao tipo de resposta pedido.
    if intencao == "exemplo":
        indicadores = (
            "por exemplo", "um exemplo", "como acontece",
            "um caso", "por meio de", "por meio da",
            "por meio do", "quando uma", "quando um"
        )
        if any(indicador in frase_normalizada for indicador in indicadores):
            pontos += 10

    elif intencao == "explicacao":
        indicadores = (
            "ocorre quando", "acontece quando", "consiste em",
            "atraves de", "atraves da", "atraves do",
            "primeiro", "depois", "em seguida",
            "processo", "etapas", "permite que"
        )
        if any(indicador in frase_normalizada for indicador in indicadores):
            pontos += 5

    elif intencao == "definicao":
        indicadores = (
            "e o processo", "e o conjunto", "define-se",
            "significa", "consiste em", "e a forma"
        )
        if any(indicador in frase_normalizada for indicador in indicadores):
            pontos += 5

    if any(
        normalizar(ruido) in frase_normalizada
        for ruido in RUIDO
    ):
        return -100

    termos = termos_chave(pergunta)

    for termo in termos:
        if termo in frase_normalizada:
            pontos += 3

    conceitos = {
        "energia da luz": 3,
        "energia luminosa": 3,
        "dioxido de carbono": 2,
        "clorofila": 2,
        "cloroplastos": 2,
        "liberta oxigenio": 3,
        "liberacao de oxigenio": 3,
        "producao de alimentos": 2,
        "produzir glicose": 2,
        "ciclo calvin": 2,
    }

    for conceito, valor in conceitos.items():
        if conceito in frase_normalizada:
            pontos += valor

    if len(frase) < 45:
        pontos -= 2
    elif len(frase) > 380:
        pontos -= 1

    return pontos

def recolher_frases(registos, pergunta):
    """Recolhe frases sem misturar títulos com explicações."""
    candidatas = []
    vistas = set()
    termos = set(termos_chave(pergunta))

    titulos = {
        "introducao", "conclusao", "mecanismo",
        "referencias", "bibliografia", "fontes",
        "resumo", "importancia", "importancia ecologica e evolutiva",
        "organismos fotossinteticos anoxigenicos",
        "caracteristicas", "vantagens", "desvantagens",
        "exemplos", "etapas", "funcionamento",
    }

    for registo in registos:
        conteudo = limpar_texto(registo.get("conteudo", ""))
        if not conteudo:
            continue

        for linha in conteudo.splitlines():
            linha = linha.strip()
            if not linha:
                continue

            normal_linha = normalizar(linha).rstrip(":.- ")
            if normal_linha in titulos:
                continue

            for frase in dividir_frases(linha):
                frase = re.sub(r"\s+", " ", frase).strip(" -*•\t")
                frase = re.sub(r"^[\d\s:.)-]+", "", frase).strip()

                if not frase or not re.search(r"[A-Za-zÀ-ÿ]", frase):
                    continue

                normal = normalizar(frase)
                palavras = set(normal.split())

                if normal.rstrip(":. ") in titulos:
                    continue

                if any(ruido in normal for ruido in (
                    "referencias bibliograficas",
                    "remover anuncios",
                    "iniciar sessao",
                    "criar conta",
                    "pagina inicial",
                    "texto recolhido da pagina",
                    "resumo da pesquisa",
                    "asth professor de matematica e fisica",
                    "professor de matematica e fisica",
                )):
                    continue

                chave = normal.rstrip(":. ")
                if chave in vistas:
                    continue
                vistas.add(chave)

                pontos = sum(5 for termo in termos if termo in palavras)

                if any(indicador in normal for indicador in (
                    " e um tipo", " e uma forma",
                    " e o processo", " consiste em",
                    " caracteriza-se por", " define-se como",
                    " refere-se a", " significa",
                )):
                    pontos += 8

                if frase.endswith(":"):
                    pontos -= 5

                if len(palavras) < 5:
                    pontos -= 2

                candidatas.append((pontos, len(candidatas), frase))

    candidatas.sort(key=lambda item: (-item[0], item[1]))
    return [frase for _, _, frase in candidatas]




def escolher(frases, termos, excluir=None):
    excluir = excluir or []
    for frase in frases:
        f = frase.lower()
        if any(t in f for t in termos):
            if not any(t in f for t in excluir):
                return frase
    return None




def enriquecer_resposta(pergunta, resposta):
    """Acrescenta informação sobre velocidade média sem duplicações."""
    pergunta_normalizada = normalizar(pergunta)

    if "velocidade media" not in pergunta_normalizada:
        return resposta

    resposta_normalizada = normalizar(resposta)

    distancia_match = re.search(
        r"(\d+(?:[.,]\d+)?)\s*(?:quilometros?|km|metros?|m)\b",
        pergunta,
        re.IGNORECASE,
    )
    tempo_match = re.search(
        r"(\d+(?:[.,]\d+)?)\s*(?:horas?|h|minutos?|min|segundos?|s)\b",
        pergunta,
        re.IGNORECASE,
    )

    complemento = ""

    tem_formula = any(
        indicador in resposta_normalizada
        for indicador in (
            "velocidade media =",
            "formula da velocidade media",
            "v = d / t",
            "distancia / tempo",
            "delta s / delta t",
        )
    )

    if not tem_formula:
        complemento += (
            "\n\nFórmula: velocidade média = distância / tempo "
            "(vₘ = d / t)."
        )

    if distancia_match and tempo_match:
        distancia = float(distancia_match.group(1).replace(",", "."))
        tempo = float(tempo_match.group(1).replace(",", "."))
        unidade_distancia = distancia_match.group(0).lower()
        unidade_tempo = tempo_match.group(0).lower()

        if "km" in unidade_distancia or "quilomet" in unidade_distancia:
            distancia_m = distancia * 1000
        else:
            distancia_m = distancia

        if unidade_tempo.startswith("h") or "hora" in unidade_tempo:
            tempo_s = tempo * 3600
        elif unidade_tempo.startswith("min"):
            tempo_s = tempo * 60
        else:
            tempo_s = tempo

        if tempo_s <= 0:
            complemento += (
                "\n\nNão é possível calcular a velocidade média "
                "com tempo igual ou inferior a zero."
            )
        else:
            velocidade = distancia_m / tempo_s

            def formatar(numero):
                if float(numero).is_integer():
                    return str(int(numero))
                return (
                    f"{numero:.4f}".rstrip("0").rstrip(".").replace(".", ",")
                )

            complemento += (
                "\n\nCálculo com os valores da pergunta:"
                f"\n- Distância: {formatar(distancia)} "
                f"{'km' if 'km' in unidade_distancia or 'quilomet' in unidade_distancia else 'm'}."
                f"\n- Tempo: {formatar(tempo)} "
                f"{'h' if unidade_tempo.startswith('h') or 'hora' in unidade_tempo else 'min' if unidade_tempo.startswith('min') else 's'}."
                f"\n- Velocidade média: {formatar(velocidade)} m/s."
            )

    elif "exemplo" not in resposta_normalizada and "por exemplo" not in resposta_normalizada:
        complemento += (
            "\n\nExemplo ilustrativo:"
            "\nUm objecto percorre 100 m em 20 s."
            "\nvₘ = 100 / 20 = 5 m/s."
        )

    return resposta + complemento


def identificar_intencao(pergunta):
    """Identifica o tipo de resposta pedido pelo utilizador."""
    pergunta = normalizar(str(pergunta))

    if any(x in pergunta for x in (
        "exemplo", "exemplifica", "da um exemplo"
    )):
        return "exemplo"

    if any(x in pergunta for x in (
        "formula", "equacao", "calcula", "calcular",
        "quanto e", "resolve", "qual e a velocidade",
        "qual a velocidade", "determina a velocidade",
        "calcule a velocidade", "calcular a velocidade",
        "qual e o valor"
    )):
        return "calculo"

    if any(x in pergunta for x in (
        "como funciona", "como ocorre", "explica",
        "explique", "descreve", "descreva", "etapas"
    )):
        return "explicacao"

    if any(x in pergunta for x in (
        "o que e", "que e", "define", "definicao",
        "significa", "quem foi", "quem e"
    )):
        return "definicao"

    return "geral"





def selecionar_frases_relevantes(frases, pergunta, assunto):
    """Prioriza definições e seleciona complementos sem redundância."""
    termos = set(termos_chave(pergunta))
    assunto_norm = normalizar(assunto)

    titulos = {
        "introducao", "conclusao", "mecanismo", "etapas",
        "referencias", "bibliografia", "fontes", "resumo",
        "objetivos", "resultados", "materiais", "metodo",
        "metodologia", "vantagens", "desvantagens",
        "caracteristicas", "importancia", "exemplos",
        "organizacao", "funcionamento",
    }

    candidatas = []
    vistas = set()

    for indice, frase in enumerate(frases):
        limpa = re.sub(r"\s+", " ", str(frase)).strip(" -*•\t")
        normal = normalizar(limpa)
        palavras = normal.split()

        if not limpa or not palavras:
            continue

        if normal.rstrip(":. ") == assunto_norm:
            continue

        if normal.rstrip(":. ") in titulos:
            continue

        if any(ruido in normal for ruido in (
            "referencias bibliograficas",
            "remover anuncios",
            "iniciar sessao",
            "criar conta",
            "pagina inicial",
            "texto recolhido da pagina",
            "resumo da pesquisa",
            "titulo da pagina",
            "tema pesquisado",
            "descubra como calcular",
            "remover anuncios",
            "exercicios sobre",
        )):
            continue

        chave = normal.rstrip(":. ")
        if chave in vistas:
            continue
        vistas.add(chave)

        pontos = sum(2 for termo in termos if termo in palavras)

        # Identificar definições científicas e conceptuais.
        indicadores_definicao = (
            " e uma grandeza",
            " e a grandeza",
            " e um processo",
            " e o processo",
            " e um tipo",
            " e uma forma",
            " e a capacidade",
            " consiste em",
            " caracteriza-se por",
            " define-se como",
            " refere-se a",
            " relaciona a",
            " indica o deslocamento",
            " mede a oposicao",
        )

        definicao = any(
            indicador in normal
            for indicador in indicadores_definicao
        )

        if definicao:
            pontos += 16

        # Evitar que exemplos e comentários narrativos
        # sejam apresentados antes da definição.
        narrativas = (
            "isso significa que",
            "imagine que",
            "suponha que",
            "considere que",
            "voce percorreu",
            "voce andou",
            "por exemplo",
            "um carro percorre",
            "um objeto percorre",
        )

        if any(expressao in normal for expressao in narrativas):
            pontos -= 12

        if any(expressao in normal for expressao in (
            "pertencem aos seguintes grupos",
            "ocorre em dois principais",
            "os principais organismos",
            "os seguintes tipos",
            "os seguintes grupos",
        )):
            pontos -= 7

        if len(palavras) < 7:
            pontos -= 2

        if len(limpa) > 500:
            pontos -= 3

        candidatas.append((pontos, indice, limpa, definicao))

    candidatas.sort(key=lambda item: (-item[0], item[1]))

    if not candidatas:
        return ""

    principal = candidatas[0]
    escolhidas = [principal]
    palavras_escolhidas = set(normalizar(principal[2]).split())

    pergunta_normalizada = normalizar(pergunta)
    pergunta_definicao = pergunta_normalizada.startswith(
        ("o que e ", "que e ", "define ", "defina ")
    )

    # Nas perguntas de definição, acrescentar até duas frases
    # complementares relevantes do mesmo registo.
    if pergunta_definicao:
        complementos = []
        marcadores_contexto = (
            "por exemplo",
            "para calcular",
            "unidade",
            "sistema internacional",
            "lei de ohm",
            "formula",
            "depende",
            "tambem",
            "também",
            "e util",
            "é útil",
            "cloroplastos",
            "clorofila",
            "durante o processo",
            "liberta oxigenio",
            "libertacao de oxigenio",
            "nao gera oxigenio",
            "materia organica",
        )

        restantes = sorted(
            candidatas,
            key=lambda item: item[1]
        )

        for item in restantes:
            if item == principal:
                continue

            pontos, indice, frase, definicao = item
            normal_frase = normalizar(frase)

            # Excluir títulos e fragmentos de páginas importadas.
            ruidos_complementos = (
                "titulo da pagina",
                "tema pesquisado",
                "resumo da pesquisa",
                "revisao por",
                "professor de matematica",
                "descubra como calcular",
                "nao pare agora",
                "leia tambem",
                "remover anuncios",
                "aceitar cookies",
                "isso significa que",
                "imagine que",
                "suponha que",
                "considere que",
                "voce percorreu",
                "voce andou",
            )

            if any(
                ruido in normal_frase
                for ruido in ruidos_complementos
            ):
                continue

            # Evitar frases que terminam a meio de uma explicação.
            if normal_frase.endswith(("...", "…")):
                continue

            palavras_frase = set(normal_frase.split())
            palavras_novas = palavras_frase - palavras_escolhidas

            # Excluir cabeçalhos que anunciam listas ou explicações.
            if frase.rstrip().endswith(":"):
                continue
            if normal_frase.startswith("fotossistema "):
                continue

            if len(palavras_frase) < 7:
                continue

            correspondencias = sum(
                1 for termo in termos
                if termo in palavras_frase
            )

            tem_contexto = any(
                marcador in normal_frase
                for marcador in marcadores_contexto
            )

            if correspondencias == 0 and not tem_contexto:
                continue

            if len(palavras_novas) < 5:
                continue

            complementos.append(item)
            palavras_escolhidas.update(palavras_novas)

            if len(complementos) >= 2:
                break

        complementos.sort(key=lambda item: item[1])

        return " ".join(
            [principal[2]]
            + [item[2] for item in complementos]
        )

    # Só acrescentar uma frase se trouxer informação nova e relevante.
    for item in candidatas[1:]:
        pontos, indice, frase, definicao = item

        # Um complemento só entra se tiver relação lexical
        # com a pergunta ou com o assunto pesquisado.
        normal_complemento = normalizar(frase)
        palavras_complemento = set(normal_complemento.split())
        correspondencias = sum(
            1 for termo in termos
            if termo in palavras_complemento
        )

        if correspondencias == 0:
            continue

        if pontos < 3:
            continue

        palavras = set(normalizar(frase).split())
        novas = palavras - palavras_escolhidas

        if len(novas) < 5:
            continue

        escolhidas.append(item)
        palavras_escolhidas.update(novas)

        if len(escolhidas) >= 2:
            break

    escolhidas.sort(key=lambda item: item[1])
    return " ".join(item[2] for item in escolhidas)



def simplificar_resposta_cientifica(pergunta, resposta):
    """Dá respostas introdutórias específicas a perguntas científicas."""
    pergunta_norm = normalizar(pergunta)

    if "estrela" in pergunta_norm and any(
        termo in pergunta_norm
        for termo in ("produzem energia", "produz energia",
                      "geram energia", "gera energia",
                      "energia das estrelas")
    ):
        return (
            "As estrelas produzem energia através da fusão nuclear "
            "no seu núcleo. Nesse processo, núcleos de hidrogénio "
            "combinam-se para formar hélio, libertando uma grande "
            "quantidade de energia. Essa energia propaga-se para o "
            "exterior e acaba por ser emitida como luz e calor.\n"
            "Fonte: https://pt.wikipedia.org/wiki/Estrela"
        )

    if "estrela" in pergunta_norm and any(
        termo in pergunta_norm
        for termo in ("emitem luz", "emite luz", "luz das estrelas",
                      "brilham", "brilha")
    ):
        return (
            "As estrelas emitem luz porque o seu interior está a "
            "temperaturas extremamente elevadas. A energia libertada "
            "pela fusão nuclear chega às camadas exteriores e é emitida "
            "sob a forma de radiação, incluindo luz visível.\n"
            "Fonte: https://pt.wikipedia.org/wiki/Estrela"
        )

    if "estrela" in pergunta_norm:
        return (
            "As estrelas são grandes esferas de gás muito quente, "
            "constituídas principalmente por hidrogénio e hélio. "
            "Produzem energia no seu interior e emitem luz própria.\n"
            "Fonte: https://pt.wikipedia.org/wiki/Estrela"
        )

    return resposta

def gerar_resposta(pergunta, registos):
    import re

    if not registos:
        return (
            "Ainda não encontrei informação suficientemente relevante "
            "na minha base de conhecimento sobre essa pergunta."
        )

    pergunta_original = str(pergunta).strip()
    pergunta_norm = normalizar(pergunta_original)

    rotulos = {
        "definicao": "Definição:",
        "explicacao": "Explicação:",
        "exemplo": "Exemplo:",
        "calculo": "Resolução:",
        "geral": "Resposta:"
    }

    intencao = identificar_intencao(pergunta_original)
    assunto_perguntado = None
    resposta_especial = None

    # Respostas diretas para perguntas que exigem uma função,
    # localização ou explicação biológica específica.
    if "cloroplasto" in pergunta_norm:
        assunto_perguntado = "Cloroplasto"

        if any(x in pergunta_norm for x in ("funcao", "serve")):
            resposta_especial = (
                "O cloroplasto é a organela celular onde ocorre a "
                "fotossíntese. A sua função principal é permitir que "
                "a energia luminosa seja utilizada para produzir "
                "açúcares a partir de água e dióxido de carbono."
            )

    if "fotossintese" in pergunta_norm and "onde" in pergunta_norm:
        assunto_perguntado = "Fotossíntese"
        resposta_especial = (
            "Nas plantas, a fotossíntese ocorre principalmente nos "
            "cloroplastos das células das folhas. A clorofila presente "
            "nesses organelos absorve a energia luminosa."
        )

    if "unidade" in pergunta_norm and (
        "vivos" in pergunta_norm or "vida" in pergunta_norm
    ):
        assunto_perguntado = "Célula"
        resposta_especial = (
            "A célula é a unidade estrutural e funcional básica "
            "dos seres vivos. Todos os organismos são constituídos "
            "por uma ou mais células."
        )

    if "respiracao celular" in pergunta_norm:
        assunto_perguntado = "Respiração celular"

        if any(x in pergunta_norm for x in ("funcao", "serve")):
            resposta_especial = (
                "A função da respiração celular é libertar energia "
                "dos nutrientes, como a glicose, e permitir que a "
                "célula produza ATP, molécula utilizada nos processos "
                "que necessitam de energia."
            )

    if "energia" in pergunta_norm and (
        "celulas" in pergunta_norm or "celula" in pergunta_norm
    ):
        assunto_perguntado = "Respiração celular"
        resposta_especial = (
            "As células obtêm energia principalmente através da "
            "degradação dos nutrientes, como a glicose. Na respiração "
            "celular, a energia libertada é utilizada para produzir "
            "ATP, que fornece energia para as atividades celulares."
        )

    if resposta_especial:
        linhas = [
            "RESPOSTA DA MINHA IA",
            "=" * 32,
            "",
            rotulos.get(intencao, "Resposta:"),
            resposta_especial
        ]

        # Acrescentar uma fonte apenas se houver registo do assunto.
        for registo in registos:
            assunto = normalizar(registo.get("assunto", ""))
            fonte = str(registo.get("fonte", "")).strip()

            if (
                assunto_perguntado
                and normalizar(assunto_perguntado) in assunto
                and fonte.startswith(("https://", "http://"))
            ):
                linhas.extend(["", "Fonte registada:", fonte])
                break

        return enriquecer_resposta(
            pergunta_original,
            "\n".join(linhas)
        )

    # Resposta normal: escolher o registo mais relacionado.
    termos = set(termos_chave(pergunta_original))
    avaliados = []

    for registo in registos:
        assunto = str(registo.get("assunto", "")).strip()
        titulo = str(registo.get("titulo", "")).strip()
        conteudo = str(registo.get("conteudo", "")).strip()

        if not conteudo:
            continue

        assunto_norm = normalizar(assunto)
        titulo_norm = normalizar(titulo)
        conteudo_norm = normalizar(conteudo)

        # Classificação melhorada dos conhecimentos.
        pontos = 0
        palavras_assunto = set(assunto_norm.split())
        palavras_titulo = set(titulo_norm.split())
        palavras_conteudo = set(conteudo_norm.split())

        for termo in termos:
            if termo in palavras_assunto:
                pontos += 12
            elif termo in palavras_titulo:
                pontos += 8

            if termo in palavras_conteudo:
                pontos += 2

        # Favorecer assuntos que correspondem diretamente à pergunta.
        if termos and termos.issubset(palavras_assunto):
            pontos += 15

            # Evitar que um subtema ultrapasse o assunto principal.
            palavras_extra = palavras_assunto - termos
            if palavras_extra:
                pontos -= min(12, 6 * len(palavras_extra))

        # Valorizar definições e explicações conceptuais.
        indicadores_definicao = (
            " e uma grandeza",
            " e um processo",
            " e definido como",
            " e definida como",
            " consiste em",
            " corresponde a",
            " caracteriza-se por",
            " refere-se a",
            " significa",
            " grandeza que",
        )

        if any(x in conteudo_norm for x in indicadores_definicao):
            pontos += 8

        # Penalizar texto importado com ruído de páginas web.
        ruidos_web = (
            "texto recolhido da pagina",
            "resumo da pesquisa",
            "tema pesquisado",
            "remover anuncios",
            "iniciar sessao",
            "criar conta",
            "aceitar cookies",
        )

        if any(ruido in conteudo_norm for ruido in ruidos_web):
            pontos -= 8

        # Penalizar conteúdos demasiado curtos para explicar um conceito.
        if len(conteudo.split()) < 7:
            pontos -= 5

        # Penalizar conteúdos excessivamente extensos.
        if len(conteudo) > 5000:
            pontos -= 4

        avaliados.append((pontos, registo))

    if not avaliados:
        return (
            "Encontrei registos, mas não consegui selecionar "
            "uma resposta suficientemente clara."
        )

    avaliados.sort(key=lambda item: item[0], reverse=True)

    # Validar a relevância, reconhecendo abreviaturas conhecidas.
    melhor_pontuacao, melhor_registo = avaliados[0]

    assunto_melhor = normalizar(
        str(melhor_registo.get("assunto", "")).strip()
    )
    materia_melhor = normalizar(
        str(melhor_registo.get("disciplina", "")).strip()
    )
    termos_pergunta = set(termos)
    termos_assunto = set(termos_chave(assunto_melhor))

    pergunta_mmc = (
        "mmc" in termos_pergunta
        or {"minimo", "multiplo", "comum"}.issubset(termos_pergunta)
    )
    registo_mmc = (
        assunto_melhor == "mmc"
        and materia_melhor == "matematica"
    )

    if pergunta_mmc and registo_mmc:
        # A correspondência exata com o assunto é suficiente.
        pass
    else:
        assunto_teste = assunto_melhor.split()
        titulo_teste = normalizar(
            str(melhor_registo.get("titulo", ""))
        ).split()
        conteudo_teste = normalizar(
            str(melhor_registo.get("conteudo", ""))
        ).split()

        palavras_registo = (
            set(assunto_teste)
            | set(titulo_teste)
            | set(conteudo_teste)
        )
        correspondencias = termos_pergunta & palavras_registo

        minimo_correspondencias = 2 if len(termos_pergunta) >= 4 else 1

        if (
            melhor_pontuacao < 8
            or len(correspondencias) < minimo_correspondencias
        ):
            return (
                "Ainda não encontrei informação suficientemente "
                "relevante na minha base de conhecimento para "
                "responder a essa pergunta. A pergunta precisa "
                "de ser investigada ou de receber um conhecimento "
                "validado."
            )

    # Usar sempre o assunto e o conteúdo do mesmo registo selecionado.
    registo = melhor_registo
    assunto = str(registo.get("assunto", "")).strip()
    titulo = str(registo.get("titulo", "")).strip()

    frases = recolher_frases([registo], pergunta_original)
    resposta = selecionar_frases_relevantes(
        frases,
        pergunta_original,
        assunto or titulo,
    )

    # Resposta directa para cálculos de velocidade média.
    pergunta_normalizada = normalizar(pergunta_original)

    if "velocidade media" in pergunta_normalizada:
        if intencao == "definicao":
            resposta = (
                "A velocidade média é a razão entre a distância "
                "total percorrida e o tempo total gasto no percurso."
            )
        elif intencao == "calculo":
            resposta = (
                "A velocidade média calcula-se dividindo a "
                "distância total pelo tempo total."
            )

    identificacao = assunto or titulo

    # Evitar repetir o assunto quando já aparece no início
    # da resposta seleccionada.
    if identificacao and resposta:
        inicio = resposta.lstrip()
        titulo_norm = normalizar(identificacao)
        inicio_norm = normalizar(inicio)

        if inicio_norm.startswith(titulo_norm):
            resto = inicio[len(identificacao):]
            if resto.startswith(":"):
                resposta = resto[1:].lstrip()
            elif resto.startswith(" - "):
                resposta = resto[3:].lstrip()

    linhas = [
        "RESPOSTA DA MINHA IA",
        "=" * 32,
        "",
        rotulos.get(intencao, "Resposta:"),
        resposta
    ]

    fonte = str(registo.get("fonte", "")).strip()

    if fonte.startswith(("https://", "http://")):
        linhas.extend(["", "Fonte registada:", fonte])

    resposta_final = "\n".join(linhas)
    resposta_final = simplificar_resposta_cientifica(
        pergunta_original, resposta_final
    )
    return enriquecer_resposta(pergunta_original, resposta_final)
def responder_pesquisa(pergunta, limite=10):
    from base_conhecimento import (
        inicializar_base,
        pesquisar_conhecimento
    )

    pergunta = str(pergunta).strip()

    if not pergunta:
        return "Escreve uma pergunta para eu pesquisar."

    try:
        limite = max(1, min(int(limite), 20))
    except (TypeError, ValueError):
        limite = 10

    inicializar_base()

    # Pesquisar somente a pergunta completa.
    # Não misturar resultados de palavras isoladas.
    try:
        registos = pesquisar_conhecimento(
            pergunta,
            limite=limite
        )
    except Exception as erro:
        return (
            "Não foi possível pesquisar a base de conhecimento. "
            f"Detalhe: {erro}"
        )

    if not registos:
        return gerar_resposta(pergunta, [])

    # A base de conhecimento já seleciona os registos
    # correspondentes ao assunto pesquisado.
    return gerar_resposta(pergunta, registos[:limite])



if __name__ == "__main__":
    pergunta = input("Qual é a tua pergunta? ").strip()
    print()
    print(responder_pesquisa(pergunta))
