from pathlib import Path
import shutil


def responder(pergunta, disciplina=None):
    pergunta = str(pergunta).strip()

    if not pergunta:
        return "Escreve uma pergunta primeiro."

    try:
        from kivy.app import App

        app = App.get_running_app()

        if app is None:
            return "A aplicação Android ainda não foi iniciada."

        pasta_app = Path(__file__).resolve().parent
        pasta_dados = Path(app.user_data_dir)
        pasta_dados.mkdir(parents=True, exist_ok=True)

        base_inicial = pasta_app / "conhecimento_inicial.db"
        base_persistente = pasta_dados / "conhecimento.db"

        if not base_inicial.is_file():
            return "A base inicial de conhecimento não foi encontrada."

        # Copiar apenas na primeira execução.
        # Nunca substituir a base de dados já utilizada.
        if not base_persistente.exists():
            shutil.copy2(base_inicial, base_persistente)

        import base_conhecimento

        # A IA utiliza a base privada e persistente do Android.
        base_conhecimento.BASE = base_persistente

        from resposta_inteligente import responder_pesquisa

        return responder_pesquisa(pergunta, limite=5)

    except Exception as erro:
        return (
            "Não foi possível obter uma resposta da IA: "
            f"{type(erro).__name__}: {erro}"
        )
