from kivy.app import App
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.textinput import TextInput
from kivy.core.window import Window
from kivy.clock import Clock
import threading

from disciplinas import DISCIPLINAS


Window.clearcolor = (0.055, 0.075, 0.13, 1)


class Botao(Button):
    def __init__(self, **kwargs):
        kwargs.setdefault("background_normal", "")
        kwargs.setdefault("background_color", (0.15, 0.36, 0.72, 1))
        kwargs.setdefault("color", (1, 1, 1, 1))
        kwargs.setdefault("size_hint_y", None)
        kwargs.setdefault("height", dp(48))
        super().__init__(**kwargs)


class MinhaIAApp(App):
    def build(self):
        self.title = "Minha IA Aprendiz"

        self.navegacao = ScreenManager()
        self.criar_inicio()
        self.criar_disciplinas()
        self.criar_perguntas()
        self.criar_biblia()
        self.criar_progresso()

        return self.navegacao

    def novo_ecra(self, nome):
        ecra = Screen(name=nome)
        self.navegacao.add_widget(ecra)
        return ecra

    def base_ecra(self, nome, titulo):
        ecra = self.novo_ecra(nome)
        raiz = BoxLayout(
            orientation="vertical",
            padding=dp(18),
            spacing=dp(12),
        )

        cabecalho = Label(
            text=f"[b]{titulo}[/b]",
            markup=True,
            font_size="23sp",
            size_hint_y=None,
            height=dp(52),
            color=(0.45, 0.75, 1, 1),
        )
        raiz.add_widget(cabecalho)

        conteudo = BoxLayout(
            orientation="vertical",
            spacing=dp(12),
        )
        raiz.add_widget(conteudo)

        voltar = Botao(
            text="← Voltar ao início",
            background_color=(0.20, 0.24, 0.34, 1),
        )
        voltar.bind(on_release=lambda *_: self.ir("inicio"))
        raiz.add_widget(voltar)

        ecra.add_widget(raiz)
        return conteudo

    def adicionar_texto(self, area, texto, tamanho=16, altura=None):
        etiqueta = Label(
            text=texto,
            font_size=f"{tamanho}sp",
            color=(0.91, 0.93, 0.97, 1),
            halign="left",
            valign="middle",
            size_hint_y=None if altura else 1,
            height=dp(altura) if altura else None,
        )
        etiqueta.bind(
            size=lambda obj, valor: setattr(obj, "text_size", valor)
        )
        area.add_widget(etiqueta)
        return etiqueta

    def criar_inicio(self):
        area = self.base_ecra("inicio", "MINHA IA APRENDIZ")

        self.adicionar_texto(
            area,
            "Aprende, explora e desenvolve o teu conhecimento.",
            16,
            65,
        )

        painel = BoxLayout(
            orientation="vertical",
            padding=dp(14),
            spacing=dp(8),
            size_hint_y=None,
            height=dp(150),
        )
        painel.add_widget(Label(
            text="[b]ÁREAS EM DESTAQUE[/b]",
            markup=True,
            color=(1, 1, 1, 1),
            font_size="17sp",
        ))

        destaques = GridLayout(
            cols=2,
            spacing=dp(8),
            size_hint_y=None,
            height=dp(65),
        )

        for disciplina in ("Matemática", "Física"):
            botao = Botao(
                text=disciplina,
                background_color=(0.12, 0.47, 0.77, 1),
            )
            botao.bind(
                on_release=lambda _, d=disciplina:
                self.abrir_disciplina(d)
            )
            destaques.add_widget(botao)

        painel.add_widget(destaques)
        area.add_widget(painel)

        opcoes = [
            ("📚  Todas as disciplinas", "disciplinas"),
            ("🤖  Fazer uma pergunta", "perguntas"),
            ("📖  Bíblia e estudos bíblicos", "biblia"),
            ("📊  Meu progresso", "progresso"),
        ]

        for texto, destino in opcoes:
            botao = Botao(text=texto)
            botao.bind(
                on_release=lambda _, d=destino: self.ir(d)
            )
            area.add_widget(botao)

        self.adicionar_texto(
            area,
            "30 disciplinas disponíveis na interface.",
            13,
            35,
        )

    def criar_disciplinas(self):
        area = self.base_ecra("disciplinas", "DISCIPLINAS")

        pesquisa = TextInput(
            hint_text="Pesquisar uma disciplina...",
            multiline=False,
            size_hint_y=None,
            height=dp(48),
            padding=dp(12),
        )
        area.add_widget(pesquisa)

        scroll = ScrollView()
        lista = GridLayout(
            cols=1,
            spacing=dp(7),
            size_hint_y=None,
        )
        lista.bind(minimum_height=lista.setter("height"))
        scroll.add_widget(lista)
        area.add_widget(scroll)

        def preencher(filtro=""):
            lista.clear_widgets()
            for disciplina in DISCIPLINAS:
                if filtro.casefold() not in disciplina.casefold():
                    continue
                botao = Botao(
                    text=disciplina,
                    height=dp(44),
                    background_color=(0.12, 0.17, 0.27, 1),
                )
                botao.bind(
                    on_release=lambda _, d=disciplina:
                    self.abrir_disciplina(d)
                )
                lista.add_widget(botao)

        pesquisa.bind(text=lambda _, valor: preencher(valor))
        preencher()

    def abrir_disciplina(self, disciplina):
        self.disciplina_atual = disciplina
        self.ir("perguntas")

    def criar_perguntas(self):
        area = self.base_ecra("perguntas", "MINHA IA")

        self.selecao_disciplina = Label(
            text="Disciplina: escolha uma área",
            size_hint_y=None,
            height=dp(45),
            color=(0.45, 0.75, 1, 1),
        )
        area.add_widget(self.selecao_disciplina)

        self.campo_pergunta = TextInput(
            hint_text="Escreve a tua pergunta aqui...",
            multiline=True,
            size_hint_y=None,
            height=dp(120),
            padding=dp(12),
        )
        area.add_widget(self.campo_pergunta)

        responder = Botao(text="Perguntar à Minha IA")
        responder.bind(on_release=self.preparar_pergunta)
        area.add_widget(responder)

        self.resposta = Label(
            text=(
                "Escreve uma pergunta e toca em Perguntar à Minha IA."
            ),
            halign="left",
            valign="top",
            color=(0.91, 0.93, 0.97, 1),
        )
        area.add_widget(self.resposta)

    def preparar_pergunta(self, *_):
        pergunta = self.campo_pergunta.text.strip()

        if not pergunta:
            self.resposta.text = "Escreve uma pergunta primeiro."
            return

        self.resposta.text = "A Minha IA está a preparar a resposta..."

        disciplina = getattr(self, "disciplina_atual", None)

        def consultar():
            try:
                from motor_ligacao import responder
                texto = responder(pergunta, disciplina)
            except Exception as erro:
                texto = f"Erro na consulta: {type(erro).__name__}: {erro}"

            Clock.schedule_once(
                lambda _dt: setattr(self.resposta, "text", str(texto)),
                0,
            )

        threading.Thread(target=consultar, daemon=True).start()

    def criar_biblia(self):
        area = self.base_ecra("biblia", "BÍBLIA E ESTUDOS")

        self.adicionar_texto(
            area,
            "Espaço reservado para a Bíblia, meditações "
            "e comentários bíblicos existentes.",
            16,
            100,
        )

        self.adicionar_texto(
            area,
            "Os conteúdos serão ligados aos ficheiros "
            "do projeto original numa etapa posterior.",
            14,
            100,
        )

    def criar_progresso(self):
        area = self.base_ecra("progresso", "MEU PROGRESSO")

        self.adicionar_texto(
            area,
            "Aqui ficará o teu progresso de aprendizagem.",
            17,
            65,
        )

        self.adicionar_texto(
            area,
            "A pontuação, os exercícios e a memória "
            "serão ligados ao sistema existente depois "
            "de verificarmos a integração.",
            15,
            120,
        )

    def ir(self, destino):
        self.navegacao.current = destino

        if destino == "perguntas":
            disciplina = getattr(
                self, "disciplina_atual", ""
            )
            self.selecao_disciplina.text = (
                f"Disciplina: {disciplina}"
                if disciplina
                else "Disciplina: escolha uma área"
            )


if __name__ == "__main__":
    MinhaIAApp().run()
