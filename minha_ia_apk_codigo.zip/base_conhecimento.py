import sqlite3
from pathlib import Path
from datetime import datetime

BASE = Path(__file__).resolve().parent / "conhecimento.db"


def ligar():
    con = sqlite3.connect(str(BASE))
    con.row_factory = sqlite3.Row
    return con


def inicializar_base():
    with ligar() as con:
        colunas = {
            linha["name"]
            for linha in con.execute(
                "PRAGMA table_info(conhecimentos)"
            )
        }

        if not colunas:
            con.execute("""
                CREATE TABLE conhecimentos (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    materia TEXT NOT NULL,
                    assunto TEXT NOT NULL,
                    conteudo TEXT NOT NULL,
                    fonte TEXT DEFAULT '',
                    criado_em TEXT,
                    atualizado_em TEXT
                )
            """)



def _normalizar_texto(texto):
    import re
    import unicodedata

    texto = unicodedata.normalize("NFKD", str(texto or ""))
    texto = texto.casefold()
    texto = "".join(
        c for c in texto
        if not unicodedata.combining(c)
    )
    return re.sub(r"\s+", " ", texto).strip()

def adicionar_conhecimento(
    disciplina, assunto, titulo, conteudo, fonte=""
):
    import sqlite3

    inicializar_base()

    materia = disciplina.strip()
    if materia.casefold().startswith("disciplina:"):
        materia = materia.split(":", 1)[1].strip()

    assunto = assunto.strip()
    titulo = titulo.strip()
    conteudo = conteudo.strip()
    fonte = fonte.strip()

    if not all([materia, assunto, titulo, conteudo]):
        raise ValueError(
            "Disciplina, assunto, título e conteúdo são obrigatórios."
        )

    texto = f"{titulo}\n\n{conteudo}"

    materia_norm = _normalizar_texto(materia)
    assunto_norm = _normalizar_texto(assunto)
    texto_norm = _normalizar_texto(texto)

    with ligar() as con:
        existentes = con.execute("""
            SELECT id, materia, assunto, conteudo
            FROM conhecimentos
            ORDER BY id DESC
        """).fetchall()

        from difflib import SequenceMatcher

        for linha in existentes:
            mesma_materia = (
                _normalizar_texto(linha["materia"]) == materia_norm
            )
            mesmo_assunto = (
                _normalizar_texto(linha["assunto"]) == assunto_norm
            )
            conteudo_existente = _normalizar_texto(
                linha["conteudo"]
            )

            mesmo_conteudo = conteudo_existente == texto_norm

            if mesma_materia and mesmo_assunto and mesmo_conteudo:
                print(
                    "DUPLICADO REJEITADO: conhecimento já existente "
                    f"(ID {linha['id']})."
                )
                raise sqlite3.IntegrityError(
                    "UNIQUE constraint failed: "
                    "conhecimentos.materia, conhecimentos.assunto, "
                    "conhecimentos.conteudo"
                )

            if mesma_materia and mesmo_assunto:
                if min(len(conteudo_existente), len(texto_norm)) >= 80:
                    semelhanca = SequenceMatcher(
                        None, conteudo_existente, texto_norm
                    ).ratio()

                    if semelhanca >= 0.82:
                        print(
                            "AVISO: conteúdo semelhante ao registo "
                            f"ID {linha['id']} "
                            f"({semelhanca:.0%} de semelhança)."
                        )

        agora = datetime.now().isoformat(timespec="seconds")

        cursor = con.execute("""
            INSERT INTO conhecimentos
            (materia, assunto, conteudo, fonte, criado_em, atualizado_em)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (materia, assunto, texto, fonte, agora, agora))

    return cursor.lastrowid



def _pesquisar_conhecimento_atual(termo, disciplina=None):
    """Pesquisa conhecimentos por relevância, privilegiando o assunto."""

    import re

    inicializar_base()

    pergunta = _normalizar_texto(termo)
    palavras = re.findall(r"[a-z0-9]+", pergunta)

    ignorar = {
        "o", "a", "os", "as", "um", "uma", "uns", "umas",
        "de", "do", "da", "dos", "das", "em", "no", "na",
        "nos", "nas", "por", "para", "com", "e", "ou",
        "que", "qual", "quais", "como", "quando", "onde",
        "porque", "porquê", "é", "sao", "ser", "foi",
        "me", "diz", "explique", "explica", "defina",
        "definir", "sobre", "funciona", "funcionam",
        "produzem", "produz", "fazem", "fazer"
    }

    termos = [p for p in palavras if p not in ignorar]

    if not termos:
        termos = palavras

    # Reconhecer equivalências comuns sem depender de uma pergunta específica.
    expandidos = set(termos)

    if "mmc" in termos or (
        "minimo" in termos and "multiplo" in termos and "comum" in termos
    ):
        expandidos.update({"mmc", "minimo", "multiplo", "comum"})

    if "estrelas" in termos:
        expandidos.add("estrela")
    if "estrela" in termos:
        expandidos.add("estrelas")

    if "planetas" in termos:
        expandidos.add("planeta")
    if "planeta" in termos:
        expandidos.add("planetas")

    if "fotossintese" in termos:
        expandidos.update({"fotossintese", "fotossintetico", "fotossintetica"})

    if "eletrica" in termos or "eletrico" in termos:
        expandidos.update({"eletrica", "eletrico", "eletricidade"})

    con = ligar()

    try:
        if disciplina:
            linhas = con.execute(
                """
                SELECT id, materia, assunto, conteudo, fonte
                FROM conhecimentos
                WHERE lower(materia) = lower(?)
                """,
                (disciplina,)
            ).fetchall()
        else:
            linhas = con.execute(
                """
                SELECT id, materia, assunto, conteudo, fonte
                FROM conhecimentos
                """
            ).fetchall()
    finally:
        con.close()

    resultados = []

    for linha in linhas:
        materia = linha["materia"] or ""
        assunto = linha["assunto"] or ""
        conteudo = linha["conteudo"] or ""

        assunto_norm = _normalizar_texto(assunto)
        materia_norm = _normalizar_texto(materia)
        conteudo_norm = _normalizar_texto(conteudo)

        palavras_assunto = set(re.findall(r"[a-z0-9]+", assunto_norm))
        palavras_conteudo = set(re.findall(r"[a-z0-9]+", conteudo_norm))

        # Correspondências no assunto valem mais do que menções no texto.
        correspondencias_assunto = expandidos & palavras_assunto
        correspondencias_conteudo = expandidos & palavras_conteudo

        pontos_assunto = len(correspondencias_assunto)
        pontos_conteudo = len(correspondencias_conteudo)

        pontos = pontos_assunto * 20 + pontos_conteudo

        # Penalizar títulos que apenas partilham uma palavra ambígua.
        fonte_norm = _normalizar_texto(linha["fonte"] or "")

        if (
            "estrela" in expandidos
            and "caminho" in palavras_assunto
            and "novela" in conteudo_norm
        ):
            pontos -= 50

        # Exigir uma ligação real ao assunto ou várias correspondências no texto.
        if pontos_assunto == 0 and pontos_conteudo < 2:
            continue

        if pontos <= 0:
            continue

        # Resultados com correspondência no assunto ficam acima dos
        # que apenas mencionam os termos dentro do conteúdo.
        resultados.append({
            "id": linha["id"],
            "disciplina": materia,
            "materia": materia,
            "assunto": assunto,
            "titulo": assunto,
            "conteudo": conteudo,
            "fonte": linha["fonte"],
            "_pontos": pontos,
            "_assunto_corresponde": pontos_assunto > 0,
            "_correspondencias_assunto": pontos_assunto,
        })

    resultados.sort(
        key=lambda r: (
            not r["_assunto_corresponde"],
            -r["_pontos"],
            -r["_correspondencias_assunto"],
            r["id"]
        )
    )

    # Selecionar resultados com correspondência direta no assunto.
    assuntos_diretos = []

    for r in resultados:
        assunto_norm = _normalizar_texto(r["assunto"])
        palavras_assunto = set(re.findall(r"[a-z0-9]+", assunto_norm))
        materia_norm = _normalizar_texto(r["disciplina"])

        corresponde = False

        if "mmc" in termos or (
            "minimo" in termos and "multiplo" in termos and "comum" in termos
        ):
            corresponde = (
                assunto_norm == "mmc"
                or "minimo multiplo comum" in assunto_norm
            )
            if corresponde and materia_norm != "matematica":
                corresponde = False

        elif "fotossintese" in termos:
            corresponde = (
                "fotossintese" in palavras_assunto
                and "artificial" not in palavras_assunto
            )

        elif "estrela" in termos or "estrelas" in termos:
            corresponde = (
                bool(palavras_assunto & {"estrela", "estrelas"})
                and "caminho" not in palavras_assunto
            )

        elif "resistencia" in termos:
            corresponde = (
                "resistencia" in palavras_assunto
                and materia_norm == "fisica"
            )

        elif "planeta" in termos or "planetas" in termos:
            corresponde = bool(palavras_assunto & {"planeta", "planetas"})

        else:
            corresponde = bool(expandidos & palavras_assunto)

        if corresponde:
            r["_correspondencia_direta"] = True
            assuntos_diretos.append(r)

    if assuntos_diretos:
        resultados = assuntos_diretos

    # Classificar por correspondência e qualidade do conteúdo.
    def chave_relevancia(r):
        import re

        assunto = _normalizar_texto(r.get("assunto", ""))
        materia = _normalizar_texto(r.get("disciplina", ""))
        conteudo = (r.get("conteudo", "") or "").strip()
        conteudo_norm = _normalizar_texto(conteudo)

        palavras_assunto = re.findall(r"[a-z0-9]+", assunto)
        termos_assunto = set(palavras_assunto)
        termos_pergunta = set(expandidos)

        nivel = 4

        # Priorizar o assunto específico pedido na pergunta.
        termos_especificos = termos_pergunta - {
            "o", "a", "os", "as", "um", "uma", "e",
            "de", "da", "do", "das", "dos", "que",
            "como", "qual", "quais", "por", "para",
            "pelo", "pela", "sao", "ser", "sobre",
            "funciona", "funcionam"
        }

        correspondencias = termos_assunto & termos_especificos

        if termos_assunto and termos_assunto.issubset(termos_especificos):
            nivel = 0
        elif correspondencias:
            nivel = 1

        # Casos em que o nome do assunto usa uma abreviatura.
        if (
            ("mmc" in termos or
             {"minimo", "multiplo", "comum"}.issubset(termos))
            and assunto == "mmc"
            and materia == "matematica"
        ):
            nivel = 0

        # O assunto geral não deve ultrapassar o específico.
        if "fotossintese" in termos_especificos:
            if "anoxigenica" in termos_especificos:
                if "anoxigenica" in assunto and materia == "biologia":
                    nivel = 0
                elif assunto == "fotossintese" and materia == "biologia":
                    nivel = 2
            elif assunto == "fotossintese" and materia == "biologia":
                nivel = 0
            elif assunto.startswith("fotossintese ") and materia == "biologia":
                nivel = max(nivel, 2)

        # Preferir conteúdos úteis, evitando páginas com ruído.
        palavras_conteudo = re.findall(r"[a-z0-9]+", conteudo_norm)
        qualidade = 0

        if 25 <= len(palavras_conteudo) <= 1500:
            qualidade += 2
        if 100 <= len(conteudo) <= 8000:
            qualidade += 1
        if "titulo da pagina:" in conteudo_norm:
            qualidade -= 3
        if "criar conta" in conteudo_norm or "inicio aleatorio" in conteudo_norm:
            qualidade -= 2

        return (
            nivel,
            -qualidade,
            len(palavras_assunto),
            r.get("id", 0)
        )

    resultados.sort(key=chave_relevancia)

    for r in resultados:
        r.pop("_pontos", None)
        r.pop("_assunto_corresponde", None)
        r.pop("_correspondencias_assunto", None)
        r.pop("_correspondencia_direta", None)

    return resultados
def pesquisar_conhecimento(termo, disciplina=None, limite=20):
    resultados = _pesquisar_conhecimento_atual(
        termo, disciplina
    )

    return [
        {
            **item,
            "materia": item["disciplina"]
        }
        for item in resultados[:max(0, limite)]
    ]


def analisar_cobertura():
    """Analisa a cobertura dos conteúdos existentes sem alterar os dados."""
    inicializar_base()

    with ligar() as con:
        linhas = con.execute("""
            SELECT
                materia,
                COUNT(*) AS quantidade,
                SUM(CASE WHEN TRIM(COALESCE(fonte, '')) = ''
                    THEN 1 ELSE 0 END) AS sem_fonte,
                SUM(CASE WHEN LENGTH(TRIM(conteudo)) < 150
                    THEN 1 ELSE 0 END) AS curtos
            FROM conhecimentos
            GROUP BY materia
            ORDER BY quantidade ASC, materia ASC
        """).fetchall()

        total = con.execute(
            "SELECT COUNT(*) FROM conhecimentos"
        ).fetchone()[0]

    return {
        "total": total,
        "disciplinas": [
            {
                "disciplina": linha["materia"],
                "quantidade": linha["quantidade"],
                "sem_fonte": linha["sem_fonte"] or 0,
                "curtos": linha["curtos"] or 0
            }
            for linha in linhas
        ]
    }


def diagnosticar_qualidade():
    """Produz um diagnóstico detalhado sem modificar os conhecimentos."""
    inicializar_base()

    with ligar() as con:
        total = con.execute(
            "SELECT COUNT(*) FROM conhecimentos"
        ).fetchone()[0]

        curtos = con.execute("""
            SELECT id, materia, assunto, LENGTH(TRIM(conteudo)) AS tamanho
            FROM conhecimentos
            WHERE LENGTH(TRIM(conteudo)) < 150
            ORDER BY tamanho ASC
        """).fetchall()

        sem_fonte = con.execute("""
            SELECT id, materia, assunto
            FROM conhecimentos
            WHERE TRIM(COALESCE(fonte, '')) = ''
            ORDER BY materia, assunto
        """).fetchall()

        categorias = con.execute("""
            SELECT id, materia, assunto
            FROM conhecimentos
            WHERE materia IN ('Geral', 'Ajuda')
               OR materia LIKE 'Disciplina:%'
            ORDER BY materia, id
        """).fetchall()

        disciplinas = con.execute("""
            SELECT materia, COUNT(*) AS quantidade
            FROM conhecimentos
            GROUP BY materia
            ORDER BY quantidade ASC, materia ASC
        """).fetchall()

        possiveis_repetidos = con.execute("""
            SELECT assunto, COUNT(*) AS quantidade,
                   GROUP_CONCAT(DISTINCT materia) AS materias
            FROM conhecimentos
            GROUP BY assunto, conteudo
            HAVING COUNT(DISTINCT materia) > 1
            ORDER BY quantidade DESC
        """).fetchall()

    print("\n=== DIAGNÓSTICO DA BASE DE CONHECIMENTO ===")
    print("Total de registos:", total)

    print("\n=== DISCIPLINAS COM POUCOS REGISTOS (ATÉ 3) ===")
    poucos = [r for r in disciplinas if r["quantidade"] <= 3]
    if poucos:
        for r in poucos:
            print(f'{r["materia"]}: {r["quantidade"]} registo(s)')
    else:
        print("Nenhuma.")

    print("\n=== CONTEÚDOS CURTOS (MENOS DE 150 CARACTERES) ===")
    print("Total:", len(curtos))
    for r in curtos:
        print(
            f'ID {r["id"]} | {r["materia"]} | '
            f'{r["assunto"]} | {r["tamanho"]} caracteres'
        )

    print("\n=== REGISTOS SEM FONTE ===")
    print("Total:", len(sem_fonte))
    for r in sem_fonte:
        print(f'ID {r["id"]} | {r["materia"]} | {r["assunto"]}')

    print("\n=== CATEGORIAS A REVER ===")
    print("Total:", len(categorias))
    for r in categorias:
        print(f'ID {r["id"]} | {r["materia"]} | {r["assunto"]}')

    print("\n=== POSSÍVEIS REPETIÇÕES ENTRE DISCIPLINAS ===")
    print("Grupos:", len(possiveis_repetidos))
    for r in possiveis_repetidos:
        print(f'{r["assunto"]} | Disciplinas: {r["materias"]}')

    print("\nDiagnóstico concluído. Nenhum conhecimento foi alterado.")


if __name__ == "__main__":
    inicializar_base()

    print("BASE DE CONHECIMENTO — MINHA IA APRENDIZ")
    print("1. Adicionar conhecimento")
    print("2. Pesquisar conhecimento")
    print("3. Listar disciplinas")
    print("4. Listar conteúdos")
    print("0. Sair")

    while True:
        opcao = input("\nEscolha: ").strip()

        if opcao == "0":
            break

        elif opcao == "1":
            disciplina = input("Disciplina: ")
            assunto = input("Assunto: ")
            titulo = input("Título: ")
            conteudo = input("Conteúdo: ")
            fonte = input("Fonte (opcional): ")

            try:
                identificador = adicionar_conhecimento(
                    disciplina, assunto, titulo, conteudo, fonte
                )
                print("Guardado com sucesso. ID:", identificador)
            except (ValueError, sqlite3.Error) as erro:
                print("Erro:", erro)

        elif opcao == "2":
            termo = input("O que queres pesquisar? ")
            resultados = pesquisar_conhecimento(termo)

            if not resultados:
                print("Nenhum conteúdo encontrado.")

            for item in resultados:
                print(
                    f"\n[{item['id']}] {item['disciplina']} - "
                    f"{item['assunto']}"
                )
                print(item["titulo"])
                print(item["conteudo"])
                if item["fonte"]:
                    print("Fonte:", item["fonte"])

        elif opcao == "3":
            for item in listar_disciplinas():
                print(item["disciplina"], "-", item["quantidade"])

        elif opcao == "4":
            for item in listar_conhecimentos():
                print(
                    item["id"], "|", item["disciplina"],
                    "|", item["assunto"], "|", item["titulo"]
                )

        else:
            print("Opção inválida.")


def atualizar_conhecimento(
    id_conhecimento,
    novo_titulo,
    novo_conteudo,
    nova_fonte=None,
    confirmar=False
):
    """
    Actualiza um conhecimento apenas com confirmação explícita.
    Arquiva a versão anterior antes de efectuar a alteração.
    """
    inicializar_base()

    novo_titulo = novo_titulo.strip()
    novo_conteudo = novo_conteudo.strip()

    if not novo_titulo or not novo_conteudo:
        raise ValueError("Título e conteúdo são obrigatórios.")

    novo_texto = f"{novo_titulo}\n\n{novo_conteudo}"

    with ligar() as con:
        atual = con.execute("""
            SELECT id, materia, assunto, conteudo, fonte,
                   criado_em, atualizado_em
            FROM conhecimentos
            WHERE id = ?
        """, (id_conhecimento,)).fetchone()

        if atual is None:
            raise ValueError(
                f"Conhecimento com ID {id_conhecimento} não encontrado."
            )

        if len(novo_texto.strip()) < len(atual["conteudo"].strip()):
            raise ValueError(
                "Actualização recusada: o novo conteúdo é mais curto. "
                "Revê-o antes de tentar novamente."
            )

        if _normalizar_texto(novo_texto) == _normalizar_texto(
            atual["conteudo"]
        ):
            print("O conteúdo é igual ao existente. Nada foi alterado.")
            return False

        if not confirmar:
            print(
                "Actualização não executada. "
                "Repete com confirmar=True após rever o novo conteúdo."
            )
            return False

        agora = datetime.now().isoformat(timespec="seconds")

        con.execute("""
            INSERT INTO conhecimentos_arquivo
            (id_original, materia, assunto, conteudo, fonte,
             criado_em, atualizado_em, motivo)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            atual["id"], atual["materia"], atual["assunto"],
            atual["conteudo"], atual["fonte"] or "",
            atual["criado_em"], atual["atualizado_em"],
            "Versão anterior a uma actualização"
        ))

        fonte_final = (
            atual["fonte"] or ""
            if nova_fonte is None
            else nova_fonte.strip()
        )

        con.execute("""
            UPDATE conhecimentos
            SET conteudo = ?, fonte = ?, atualizado_em = ?
            WHERE id = ?
        """, (
            novo_texto, fonte_final, agora, id_conhecimento
        ))

    print(
        f"Conhecimento ID {id_conhecimento} actualizado. "
        "A versão anterior foi arquivada."
    )
    return True


def encontrar_conhecimentos_semelhantes(
    disciplina, assunto, titulo, conteudo, limiar=0.82, excluir_id=None
):
    """Procura conteúdos semelhantes sem alterar a base de dados."""
    from difflib import SequenceMatcher

    inicializar_base()

    materia_norm = _normalizar_texto(disciplina)
    assunto_norm = _normalizar_texto(assunto)
    texto_norm = _normalizar_texto(
        f"{titulo.strip()}\n\n{conteudo.strip()}"
    )

    if not materia_norm or not assunto_norm or not texto_norm:
        return []

    encontrados = []

    with ligar() as con:
        linhas = con.execute("""
            SELECT id, materia, assunto, conteudo, fonte
            FROM conhecimentos
            ORDER BY id DESC
        """).fetchall()

        for linha in linhas:
            if excluir_id is not None and linha["id"] == excluir_id:
                continue

            if _normalizar_texto(linha["materia"]) != materia_norm:
                continue

            if _normalizar_texto(linha["assunto"]) != assunto_norm:
                continue

            existente = _normalizar_texto(linha["conteudo"])

            if existente == texto_norm:
                continue

            if min(len(existente), len(texto_norm)) < 80:
                continue

            semelhanca = SequenceMatcher(
                None, existente, texto_norm
            ).ratio()

            if semelhanca >= limiar:
                encontrados.append({
                    "id": linha["id"],
                    "materia": linha["materia"],
                    "assunto": linha["assunto"],
                    "conteudo": linha["conteudo"],
                    "fonte": linha["fonte"],
                    "semelhanca": round(semelhanca, 4)
                })

    return encontrados

